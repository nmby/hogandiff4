Please see ..\java.desktop\pipewire.md
